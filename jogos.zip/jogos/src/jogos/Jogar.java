package jogos;
import java.util.Scanner;
public class Jogar {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		JogoDescoberta descoberta = new JogoDescoberta();
		JogoCacaPalavras cacaPalavras = new JogoCacaPalavras();
		
		boolean sair = false;
		
		while(sair==false) {
			System.out.println("Qual jogo você deseja jogar?\nDigite 1 para Jogo da Descoberta\nDigite 2 para jogo de Caça Palavras\n\n");
			String entrada = scanner.nextLine();
		if(entrada.equals("1")) {
			descoberta.Jogar();
			}
		else if (entrada.equals("2")) {
			cacaPalavras.Jogar();
			} 
		else if(entrada.equals("3")) {
			System.out.println("O menu será finalizado");
			sair = true;
			}
		}
	}

}