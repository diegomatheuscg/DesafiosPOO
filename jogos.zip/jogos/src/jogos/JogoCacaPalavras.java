package jogos;
import java.util.Scanner;
public class JogoCacaPalavras {
    
    public static void Jogar() {
    	Scanner scanner = new Scanner(System.in);
    	
    	CacaPalavrasMetodo metodos = new CacaPalavrasMetodo();
        String palavras[] ={"Carro","Computador", "Moto", "Mesa"};
        int tamanho = 10;

        char tabuleiro[][] = new char [tamanho][tamanho];   
        
        metodos.preencherTabuleiro(tabuleiro);
        
        String palavraSelecionada = metodos.selecionarPalavra(palavras);
        
        metodos.posicionarPalavra(tamanho, palavraSelecionada, tabuleiro);
        metodos.imprimirTabuleiro(tabuleiro);
        
        
        while(true){
            System.out.println("Digite a palavra encontrada corretamente\nDigite 1 para dica\nDigite 2 para desistir\n");
            String entrada = scanner.nextLine();
        
            if(entrada.equals("1")){
                metodos.dica(palavraSelecionada);
            }else if(entrada.equals("2")){
                System.out.println("Você desistiu\n");
                
                break;
            }else if(entrada.equals(palavraSelecionada)){
                System.out.println("Você ganhou!\n");
                break;
                
            }else{
                System.out.println("Entrada inválida. Digite novamente\n");
                continue;
            }
        }
        
    }

}