package jogos;

import java.util.Random;
import java.util.Scanner;

public class DescobertaMetodos {
	
	 public static String embaralhar (String palavra){
	        char[] letras = palavra.toCharArray();
	        Random random = new Random();
	        for(int i = 0; i < letras.length; i++) {
				int indiceAleatorio = random.nextInt(letras.length);
				
				char temp = letras[i];
				letras[i] = letras[indiceAleatorio];
				letras[indiceAleatorio] = temp;
			}
	        return new String(letras);
	    }
	 
	public static String selecionarPalavra(String palavras[]){
        Random random = new Random();
        String palavraSelecionada = palavras[random.nextInt(palavras.length)];
        return palavraSelecionada;
    }
	
	
	public static String receberTexto() {
		Scanner scanner = new Scanner(System.in);
		String entrada = scanner.nextLine();
		return entrada;
	}
	
	public static void imprimirDica(String palavra) {
		char primeiroCaractere = palavra.charAt(0);
		char ultimoCaractere = palavra.charAt(palavra.length()-1);
		System.out.println("A primeira é: " + primeiroCaractere + ". A última letra é: " + ultimoCaractere);
	}
	
}