package jogos;

import java.util.Random;

public class CacaPalavrasMetodo {
    public static String selecionarPalavra(String palavras[]){
        Random random = new Random();
        String palavraSelecionada = palavras[random.nextInt(palavras.length)];
        return palavraSelecionada;

    }

    public static void preencherTabuleiro(char tabuleiro[][]){
        Random random = new Random();
        int tamanho = tabuleiro.length;
    
        for(int i=0 ; i<tamanho;i++){
            for(int j=0; j<tamanho;j++){
                tabuleiro[i][j] = (char)('a'+ random.nextInt(25));
            }
         }
    }

    public static void imprimirTabuleiro(char tabuleiro[][]){
        int tamanho = tabuleiro.length;
        for(int i=0 ; i<tamanho;i++){
            for(int j=0; j<tamanho;j++){       
                System.out.print(tabuleiro[i][j]+" ");
            }
            System.out.println("");
         }
    }
     
    public static void posicionarPalavra(int tamanhoVetor, String palavraSelecionada, char[][] tabuleiro){
        Random random = new Random();
        int linha = random.nextInt((tamanhoVetor));
        int coluna = random.nextInt((tamanhoVetor - palavraSelecionada.length()));
        
        for(int I=0 ; I<palavraSelecionada.length();I++){
            tabuleiro[linha][coluna+I] = palavraSelecionada.charAt(I);
         }
    }

    public static void dica(String palavraSelecionada){

        char primeiraLetra = palavraSelecionada.charAt(0);
        char ultimaLetra = palavraSelecionada.charAt(palavraSelecionada.length()+1);

        System.out.println("Primeira Letra: "+primeiraLetra+
        		"\nÚltima letra: "+ ultimaLetra);
    }



}   