package jogos;
import java.util.Scanner;

public class JogoDescoberta {

	public static void Jogar() {
		String palavras[] = {"Computador", "Mesa", "cabeça"};
		
		String palavraSelecionada = DescobertaMetodos.selecionarPalavra(palavras).toLowerCase();
		String palavraEmbaralhada = DescobertaMetodos.embaralhar(palavraSelecionada);
		
		String entrada = "";
		int tentativas = 1;
		boolean acertou = false;
		
		System.out.print("Bem vindo ao Jogo da Descoberta!\n"
				+ "Para solicitar uma dica, digite 1\n"
				+ "Para desistir, digite 0\n"
				+ "=============================");
		
		System.out.print("\nA palavra embaralhada é: \"" + palavraEmbaralhada + "\"\n=============================\n");
		
		while (acertou != false) {
			System.out.print("\nDigite seu palpite: ");
			entrada = DescobertaMetodos.receberTexto();
			
			if(entrada.equals(palavraSelecionada)) {
				System.out.println("\nVocê acertou! Número de tentativas realizadas: "+ tentativas
						+"Você será retornado ao menu principal.\n\n");
				acertou = true;
				
			}
			else if(entrada.equals("1")) {
				DescobertaMetodos.imprimirDica(palavraSelecionada);
			}
			else if(entrada.equals("0")) {
				System.out.println("\nVocê desistiu. Número de tentativas realizadas: " + tentativas+"\nVocê será retornado ao menu principal.\n\n");
				break;
			}
			else {
				System.out.println("\nIncorreto, tente novamente");
				tentativas++;
			}
		}
	}
}