/**
 * 
 */
/**
 * 
 */
module ogos {
}