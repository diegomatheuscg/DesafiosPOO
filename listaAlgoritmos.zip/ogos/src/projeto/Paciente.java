package projeto;

public class Paciente {

	private String nome;
	private int gravidade;
	private int tempo;

	public Paciente(String nome, int gravidade, int tempo) {
		this.nome = nome;
		this.gravidade = gravidade;
		this.tempo = tempo;
	}

	public String getNome() {
		return this.nome;
	}

	public int getGravidade() {
		return this.gravidade;
	}

	public int getTempo() {
		return this.tempo;
	}

}
