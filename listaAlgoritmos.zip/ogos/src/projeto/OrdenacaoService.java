package projeto;

import java.util.Arrays;
import java.util.List;

public class OrdenacaoService {

	public static void bubbleSort(int[] vetor) {
		System.out.println("\nVetor original: " + Arrays.toString(vetor));
		int[] vetorAuxiliar = Arrays.copyOf(vetor, vetor.length);
		for (int i = 0; i < vetorAuxiliar.length - 1; i++) {
			for (int j = 0; j < vetorAuxiliar.length - i - 1; j++) {
				if (vetorAuxiliar[j] > vetorAuxiliar[j + 1]) {
					int temp = vetorAuxiliar[j];
					vetorAuxiliar[j] = vetorAuxiliar[j + 1];
					vetorAuxiliar[j + 1] = temp;
				}
			}
			System.out.println("Passo " + (i + 1) + ": " + Arrays.toString(vetorAuxiliar));
		}
		System.out.println("Vetor ordenado: " + Arrays.toString(vetorAuxiliar) + "\n");

	}

	public static void insertionSort(int[] vetor) {
		System.out.println("\nVetor original: " + Arrays.toString(vetor));
		int[] vetorAuxiliar = Arrays.copyOf(vetor, vetor.length);

		for (int i = 1; i < vetorAuxiliar.length; i++) {
			int chave = vetorAuxiliar[i];
			int j = i - 1;

			while (j >= 0 && vetorAuxiliar[j] > chave) {
				vetorAuxiliar[j + 1] = vetorAuxiliar[j];
				j = j - 1;
			}
			vetorAuxiliar[j + 1] = chave;

			System.out.println("Passo " + i + ": " + Arrays.toString(vetorAuxiliar));
		}
		System.out.println("Vetor ordenado: " + Arrays.toString(vetorAuxiliar) + "\n");

	}

	public static void selectionSort(int[] vetor) {
		System.out.println("\nVetor original: " + Arrays.toString(vetor));
		int[] vetorAuxiliar = Arrays.copyOf(vetor, vetor.length);
		for (int i = 0; i < vetorAuxiliar.length - 1; i++) {
			int menorIndice = i;
			for (int j = i + 1; j < vetorAuxiliar.length; j++) {
				if (vetorAuxiliar[j] < vetorAuxiliar[menorIndice]) {
					menorIndice = j;
				}
			}
			if (menorIndice != i) {
				int temp = vetorAuxiliar[i];
				vetorAuxiliar[i] = vetorAuxiliar[menorIndice];
				vetorAuxiliar[menorIndice] = temp;
			}
			System.out.println("Passo " + (i + 1) + ": " + Arrays.toString(vetorAuxiliar));
		}
		System.out.println("Vetor ordenado: " + Arrays.toString(vetorAuxiliar) + "\n");

	}

	public static List<Paciente> gestaoHospitalar(List<Paciente> pacientes) {
		// TIVE QUE ESTUDAR LIST PRA FAZER ESSA PROFESSOR... NÃO SEI SE E O QUE O SENHOR
		// QUERIA...
		for (int i = 0; i < pacientes.size(); i++) {
			for (int j = 0; j < pacientes.size() - i - 1; j++) {
				Paciente atual = pacientes.get(j);
				Paciente proximo = pacientes.get(j + 1);
				if (proximo.getGravidade() > atual.getGravidade()
						|| (proximo.getGravidade() == atual.getGravidade() && proximo.getTempo() > atual.getTempo())) {
					pacientes.set(j, proximo);
					pacientes.set(j + 1, atual);
				}
			}
		}
		return pacientes;
	}

	public static void encontrarMaior(int[] vetor) {
		int maior = vetor[0];
		for (int i = 1; i < vetor.length; i++) {
			if (vetor[i] > maior) {
				maior = vetor[i];
			}
		}

		for (int i = 0; i < vetor.length - 1; i++) {
			for (int j = 0; j < vetor.length - i - 1; j++) {
				if (vetor[j] > vetor[j + 1]) {
					int temp = vetor[j];
					vetor[j] = vetor[j + 1];
					vetor[j + 1] = temp;
				}
			}
		}

		System.out.println("Maior valor: " + maior);
		System.out.println("Vetor: " + Arrays.toString(vetor));
	}

	public static int[] ordenacaoDecrescente(int[] vetor) {
		int[] vetorAuxiliar = Arrays.copyOf(vetor, vetor.length);

		for (int i = 0; i < vetorAuxiliar.length - 1; i++) {
			for (int j = 0; j < vetorAuxiliar.length - i - 1; j++) {
				if (vetorAuxiliar[j] < vetorAuxiliar[j + 1]) {
					int temp = vetorAuxiliar[j];
					vetorAuxiliar[j] = vetorAuxiliar[j + 1];
					vetorAuxiliar[j + 1] = temp;
				}
			}
		}
		return vetorAuxiliar;
	}

	public static int[][] matriz2D(int[][] vetor) {
		int[][] vetorAuxiliar = new int[vetor.length][vetor[0].length];

		for (int i = 0; i < vetor.length; i++) {
			for (int j = 0; j < vetor[i].length; j++) {
				vetorAuxiliar[i][j] = vetor[i][j];
			}
		}

		for (int i = 0; i < vetorAuxiliar.length; i++) {
			for (int j = 0; j < vetorAuxiliar[i].length - 1; j++) {
				for (int k = 0; k < vetorAuxiliar[i].length - j - 1; k++) {
					if (vetorAuxiliar[i][k] > vetorAuxiliar[i][k + 1]) {
						int temp = vetorAuxiliar[i][k];
						vetorAuxiliar[i][k] = vetorAuxiliar[i][k + 1];
						vetorAuxiliar[i][k + 1] = temp;
					}
				}
			}
		}

		return vetorAuxiliar;
	}

	public static void nota(float[] vetor) {

		for (int i = 0; i < vetor.length - 1; i++) {
			for (int j = 0; j < vetor.length - i - 1; j++) {
				if (vetor[j] > vetor[j + 1]) {
					float temp = vetor[j];
					vetor[j] = vetor[j + 1];
					vetor[j + 1] = temp;
				}
			}
		}

		float soma = 0;
		for (float nota : vetor) {
			soma += nota;
		}

		float mediana = soma / vetor.length;
		System.out.println("Mediana: " + mediana);
	}

	public static String[] ordenacaoString(String[] vetor) {

		for (int i = 0; i < vetor.length - 1; i++) {
			for (int j = 0; j < vetor.length - i - 1; j++) {
				if (vetor[j].compareTo(vetor[j + 1]) > 0) {
					String temp = vetor[j];
					vetor[j] = vetor[j + 1];
					vetor[j + 1] = temp;
				}
			}
		}

		return vetor;
	}
}