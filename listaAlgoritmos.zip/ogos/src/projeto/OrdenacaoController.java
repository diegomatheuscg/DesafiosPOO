package projeto;

import java.util.ArrayList;
import java.util.List;

public class OrdenacaoController {
    static int vetorSorts[] = { 3, 4, 9, 2, 5, 8, 2, 1, 7 };
    static int vetor2d[][] = { { 3, 2, 1 }, { 6, 5, 4 }, { 9, 8, 7 } };
    static int vetor[] = { 3, 0, -2, 5, 8 };
    static float notas[] = { 85.0f, 70.0f, 95.0f, 60.0f, 75.0f, 80.0f };
    static int pontuacoes[] = { 250, 300, 150, 400, 350 };
    static String vetorString[] = {"bbb", "aaa", "ccc"};

    public static void main(String[] args) {
        exercicio1();
        exercicio2();
        exercicio3();
        exercicio5();
        exercicio6();
        exercicio7();
        exercicio8();
    }

    public static void exercicio1() {
    	System.out.println("\nExercicio1: ");
        System.out.print("Bubble sort: ");
        OrdenacaoService.bubbleSort(vetorSorts);
        System.out.print("Selection sort: ");
        OrdenacaoService.selectionSort(vetorSorts);
        System.out.print("Insertion: ");
        OrdenacaoService.insertionSort(vetorSorts);
        
    }

    public static void exercicio2() {
        System.out.println("\nExercício 2:");
        String vetorOriginal = "";
        String vetorModificado = "";
        int vetorReferencia[] = OrdenacaoService.ordenacaoDecrescente(vetor);

        for (int i = 0; i < vetorReferencia.length; i++) {
            vetorOriginal += (i == 0 ? "[" : "") + vetor[i] + (i < vetorReferencia.length - 1 ? ", " : "]");
            vetorModificado += (i == 0 ? "[" : "") + vetorReferencia[i] + (i < vetorReferencia.length - 1 ? ", " : "]");
        }

        System.out.println("Vetor original: " + vetorOriginal + "\nVetor modificado: " + vetorModificado);
    }

    public static void exercicio3() {
        System.out.println("\nExercício 3:");
        String vetorReferencia[] = OrdenacaoService.ordenacaoString(vetorString);

        for (String str : vetorReferencia) {
            System.out.print(str + " ");
        }
    }

    public static void exercicio5() {
        System.out.println("\nExercício 5:");
        int vetorReferencia[][] = OrdenacaoService.matriz2D(vetor2d);

        for (int i = 0; i < vetorReferencia.length; i++) {
            System.out.print("Vetor " + (i + 1) + ": ");
            for (int j = 0; j < vetorReferencia[i].length; j++) {
                System.out.print((j == 0 ? "[" : "") + vetorReferencia[i][j] + (j < vetorReferencia[i].length - 1 ? ", " : "]"));
            }
            System.out.println();
        }
    }

    public static void exercicio6() {
        System.out.println("\nExercício 6:\n\n");
        OrdenacaoService.nota(notas);

        for (int i = 0; i < notas.length; i++) {
            System.out.print((i == 0 ? "[" : "") + notas[i] + (i < notas.length - 1 ? ", " : "]"));
        }
    }

    public static void exercicio7() {
    	System.out.println("\nExercício 7");
        OrdenacaoService.encontrarMaior(pontuacoes);
    }

    public static void exercicio8() {
    	System.out.println("\nExercício 8");
        List<Paciente> pacientes = new ArrayList<>();
        pacientes.add(new Paciente("João", 3, 5));
        pacientes.add(new Paciente("Maria", 3, 10));
        pacientes.add(new Paciente("Luccas", 5, 2));

        pacientes = OrdenacaoService.gestaoHospitalar(pacientes);

        System.out.println("Lista reordenada: ");
        for (Paciente p : pacientes) {
            System.out.println(p.getNome());
        }
    }
}
