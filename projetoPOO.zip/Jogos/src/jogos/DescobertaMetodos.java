package jogos;
import java.util.Random;
public class DescobertaMetodos {
	
	 public static String embaralhar (String palavra){
	        char[] letras = palavra.toCharArray();
	        Random random = new Random();
	        for(int i = 0; i < letras.length; i++) {
				char letraAleatoria = letras[random.nextInt(letras.length)];
				
				char temp = letras[i];
				letras[i] = letras[letraAleatoria];
				letras[letraAleatoria] = temp;
			}
	        return new String(palavra);
	    }
	 
	public static String selecionarPalavra(String palavras[]){
        Random random = new Random();
        String palavraSelecionada = palavras[random.nextInt(palavras.length)];
        return palavraSelecionada;
    }
	
}
