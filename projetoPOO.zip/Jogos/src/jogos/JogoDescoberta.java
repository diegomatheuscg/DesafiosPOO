package jogos;
import java.util.Scanner;
import java.util.Random;

public class JogoDescoberta {

	public static void Jogar(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Random random = new Random();
		String palavras[] = {"Computador", "Mesa", "cabeça"};
		
	
		
		
		
	
		
		String palavraEmbaralhada = new String(letras);
		
		System.out.println("Palavra normal: "+palavraSelecionada+"\nPalavra embaralhada: "+palavraEmbaralhada);
		
		boolean acertou = false;

		while (true) {
			System.out.print("\nDigite a palavra (digite '1' para obter uma dica e '0' para desistir: ");
			String input = scanner.nextLine();

			if (input == "1") {
				System.out.println("A primeira letra é '" + palavraSelecionada.charAt(0) + "' e a última letra é '" + palavraSelecionada.charAt(palavraSelecionada.length() - 1) + "'");
			} else if (input == "0") {
				System.out.println("Você desistiu. A palavra era: " + palavraSelecionada);
				break;
			} else if (resposta.equals(palavraOriginal)) {
				System.out.println("Acertou! parabens");
				break;
			} else {
				System.out.println("Errou! Tente novamente ");
			}
		}

		
		
	}
	

}
